export declare const decodeXML: (str: string) => string;
export declare const decodeHTMLStrict: (str: string) => string;
export declare type MapType = Record<string, string>;
export declare const decodeHTML: (str: string) => string;
//# sourceMappingURL=decode.d.ts.map